set(CMAKE_HOST_SYSTEM "Linux-6.1.102")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.1.102")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/workspace/chats/1cdb19c22fcd78dca393dba5/toolchain/android-sdk/ndk/28.2.13676358/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "armv7-a")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
